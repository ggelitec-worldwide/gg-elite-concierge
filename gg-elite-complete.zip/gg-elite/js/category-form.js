// GG Elite Concierge — Shared category-page form handler
// Used by flights.html, theme-parks.html, cruises.html, events.html

(function () {
  const form = document.getElementById('requestForm');
  if (!form) return;

  const note = document.getElementById('formNote');
  const submitBtn = form.querySelector('button[type="submit"]');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    submitBtn.disabled = true;
    const originalLabel = submitBtn.textContent;
    submitBtn.textContent = 'Sending…';
    note.textContent = '';
    note.classList.remove('form-note-success', 'form-note-error');

    fetch(form.action, {
      method: 'POST',
      body: new FormData(form),
      headers: { Accept: 'application/json' }
    })
      .then((res) => {
        if (res.ok) {
          note.textContent = 'Request received — we\'ll reach out shortly to confirm.';
          note.classList.add('form-note-success');
          form.reset();
        } else {
          throw new Error('Submission failed');
        }
      })
      .catch(() => {
        note.textContent = 'Something went wrong sending that — please call us directly instead.';
        note.classList.add('form-note-error');
      })
      .finally(() => {
        submitBtn.disabled = false;
        submitBtn.textContent = originalLabel;
      });
  });

  // pre-fill "item of interest" select if a card's button was clicked
  document.addEventListener('click', (e) => {
    const target = e.target.closest('.select-item');
    if (!target) return;
    const val = target.dataset.itemName;
    const select = document.getElementById('itemSelect');
    if (select && val) {
      for (const opt of select.options) {
        if (opt.value === val) {
          select.value = val;
          break;
        }
      }
    }
    setTimeout(() => {
      const nameField = document.getElementById('name');
      if (nameField) nameField.focus();
    }, 450);
  });
})();
