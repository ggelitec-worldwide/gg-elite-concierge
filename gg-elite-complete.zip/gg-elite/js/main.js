// GG Elite Concierge — Site Behavior

(function () {
  const grid = document.getElementById('fleetGrid');
  const lotSelect = document.getElementById('lot');

  function renderFleet(filter) {
    grid.innerHTML = '';
    const items = filter === 'all' ? FLEET : FLEET.filter(c => c.class === filter);

    items.forEach((car) => {
      const card = document.createElement('article');
      card.className = 'lot-card';
      card.innerHTML = `
        <div class="lot-photo">
          <img src="${car.image}" alt="${car.name} — ${car.color}" loading="lazy">
          <span class="lot-photo-num">LOT ${car.lot}</span>
        </div>
        <div class="lot-card-body">
          <div class="lot-card-top">
            <span class="lot-year">${car.year}</span>
          </div>
          <h3 class="lot-name">${car.name}</h3>
          <p class="lot-color">${car.color}</p>
          <dl class="lot-specs">
            <div><dt>Engine</dt><dd>${car.engine}</dd></div>
            <div><dt>Output</dt><dd>${car.hp}</dd></div>
            <div><dt>0–60</dt><dd>${car.zeroSixty}</dd></div>
          </dl>
          <p class="lot-note">${car.note}</p>
          <div class="lot-foot">
            <a href="#book" class="btn btn-primary btn-small lot-select" data-lot-num="${car.lot}">Call/Booking for Availability</a>
          </div>
        </div>
      `;
      grid.appendChild(card);
    });
  }

  function populateLotSelect() {
    FLEET.forEach((car) => {
      const opt = document.createElement('option');
      opt.value = `Lot ${car.lot} — ${car.name}`;
      opt.textContent = `Lot ${car.lot} — ${car.name} (${car.year})`;
      opt.dataset.lotNum = car.lot;
      lotSelect.appendChild(opt);
    });
  }

  function bindFilters() {
    const buttons = document.querySelectorAll('.filter-btn');
    buttons.forEach((btn) => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('is-active'));
        btn.classList.add('is-active');
        renderFleet(btn.dataset.filter);
      });
    });
  }

  function bindLotSelectClicks() {
    grid.addEventListener('click', (e) => {
      const target = e.target.closest('.lot-select');
      if (!target) return;
      const lotNum = target.dataset.lotNum;
      const select = document.getElementById('lot');
      for (const opt of select.options) {
        if (opt.dataset.lotNum === lotNum) {
          select.value = opt.value;
          break;
        }
      }
      // give the anchor scroll a moment, then focus the first empty field
      setTimeout(() => {
        const nameField = document.getElementById('name');
        if (nameField) nameField.focus();
      }, 450);
    });
  }

  function bindForm() {
    const form = document.getElementById('bookForm');
    const note = document.getElementById('formNote');
    const submitBtn = form.querySelector('button[type="submit"]');

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      submitBtn.disabled = true;
      submitBtn.textContent = 'Sending…';
      note.textContent = '';
      note.classList.remove('form-note-success', 'form-note-error');

      fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: { Accept: 'application/json' }
      })
        .then((res) => {
          if (res.ok) {
            note.textContent = 'Request received — we\'ll reach out shortly to confirm.';
            note.classList.add('form-note-success');
            form.reset();
          } else {
            throw new Error('Submission failed');
          }
        })
        .catch(() => {
          note.textContent = 'Something went wrong sending that — please call us directly instead.';
          note.classList.add('form-note-error');
        })
        .finally(() => {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Submit Booking Request';
        });
    });
  }

  renderFleet('all');
  populateLotSelect();
  bindFilters();
  bindLotSelectClicks();
  bindForm();
})();
